from django import forms
from .models import Pass

class PassForm(forms.ModelForm):
    class Meta:
        model = Pass
        fields = ['student', 'pass_type', 'issue_date', 'expiration_date']

class FareCalculationForm(forms.Form):
    Source = forms.CharField(max_length=100, label='Source')
    Destination = forms.CharField(max_length=100, label='Destination')


class DepotForm(forms.Form):
    depot_name = forms.CharField(label='Enter Bus Depot Name', max_length=255)
